# Initialize library code
for f ($ZSH/lib/*.zsh); do
	source $f
done
